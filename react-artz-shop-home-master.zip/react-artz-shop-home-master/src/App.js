import { Container } from 'react-bootstrap';
import Layout from './Layout/Layout';


function App() {
  return (
    <Layout>
      <Container style={{minHeight:'15vh'}}>
      </Container>
    </Layout>
    
  );
}

export default App;