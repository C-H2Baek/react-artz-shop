import react from 'react';
import { Container } from 'react-bootstrap';

const Info = () => {
  return(
    <footer>
      <Container>
        <div style={{textAlign:'center'}}>
        Info.js
        
        </div>
      </Container>
    </footer>
  )
}

export default Info;