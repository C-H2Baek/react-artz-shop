import react from 'react';
import { Container } from 'react-bootstrap';

const Global = () => {
  return(
    <footer>
      <Container>
        <div style={{textAlign:'center'}}>
        Global.js
        언어 번역
        </div>
      </Container>
    </footer>
  )
}

export default Global;