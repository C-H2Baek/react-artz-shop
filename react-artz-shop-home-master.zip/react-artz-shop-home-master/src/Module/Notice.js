import react from 'react';
import { Container } from 'react-bootstrap';

const Notice = () => {
  return(
    <footer>
      <Container>
        <div style={{textAlign:'center'}}>
        Notice.js
        
        </div>
      </Container>
    </footer>
  )
}

export default Notice;