import react from 'react';
import { Container } from 'react-bootstrap';

const Cart = () => {
  return(
    <footer>
      <Container>
        <div style={{textAlign:'center'}}>
        Cart.js
        
        </div>
      </Container>
    </footer>
  )
}

export default Cart;