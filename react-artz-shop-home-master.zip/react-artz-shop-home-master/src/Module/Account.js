import react from 'react';
import { Container } from 'react-bootstrap';

const Account = () => {
  return(
    <footer>
      <Container>
        <div style={{textAlign:'center'}}>
        Account.js
        
        </div>
      </Container>
    </footer>
  )
}

export default Account;